#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#define M 10000

char file_name[100] = "simple_example.txt";
int tasks_num;
int done_tasks = 0;

//return the number of tasks(lines in file)
int lines_counter(char file_name[]){
    FILE *file;
    file = fopen(file_name, "r");
    int counter = 0;
    for (char c = getc(file); c != EOF; c = getc(file)) 
        if (c == '\n') 
            counter++;
    return counter;
}

typedef struct {
    int id;
    int value;
    int atime;
    int unit_count;
    int *unit_id;
}task;

typedef struct{
    task *queue;
    int head;
    int tail;
    int size;
    int capacity;
} queue;

queue main_queue;
queue unit_queues[5];
pthread_mutex_t lock;
task null_task = { .id=-1 };

int enqueue(queue *q, task t){
    if(q->size==q->capacity){
        return -1;
    }
    q->queue[q->tail] = t;
    q->tail = (q->tail+1) % q->capacity;
    q->size++;
    return 1;
}

task *dequeue(queue *q){
    if(q->size==0){
        return &null_task;
    }
    task *t = &q->queue[q->head];
    q->head = (q->head+1) % q->capacity;
    q->size--;
    return t;
}


void init_queues(){
    tasks_num = lines_counter(file_name);
    main_queue.queue = malloc( tasks_num * sizeof(task));
    main_queue.capacity = tasks_num;
    main_queue.head = 0;
    main_queue.tail = 0;
    main_queue.size = 0;
    for(int i=0; i<5; i++){
        unit_queues[i].queue = malloc( tasks_num * sizeof(task));
        unit_queues[i].capacity = tasks_num;
        unit_queues[i].head = 0;
        unit_queues[i].tail = 0;
        unit_queues[i].size = 0;
    }
    pthread_mutex_init(&lock, NULL);
}


void *receptor(void *rec_args){
    FILE *file;
    file = fopen(file_name, "r");

    // read the file and store tasks
    for(int i=0; i<tasks_num; i++){
        pthread_mutex_lock(&lock);
        fscanf(file, "%d", &main_queue.queue[i].id);
        fscanf(file, "%d", &main_queue.queue[i].value);
        fscanf(file, "%d", &main_queue.queue[i].unit_count);
        main_queue.queue[i].unit_id = malloc( main_queue.queue[i].unit_count * sizeof(int) );
        for(int j=0; j<main_queue.queue[i].unit_count; j++){
            fscanf(file, "%d", &main_queue.queue[i].unit_id[j]);
        }
        main_queue.tail = (main_queue.tail+1) % main_queue.capacity;
        main_queue.size++;
        pthread_mutex_unlock(&lock);
    }
}


void *dispatcher(void *main_q){
    task *t;
    while (done_tasks != tasks_num)
    {
        t = dequeue(&main_queue);
        if(t->id == -1){
            continue;
        }
        else{
            enqueue(&unit_queues[*t->unit_id], *t);
        }
    }
    pthread_exit(NULL);
}

void *unit(void *q){
    queue *unit_q = (queue *)q;
    task *t;
    while(done_tasks != tasks_num){
        t = dequeue(unit_q);
        if(t->id == -1){
            continue;
        }
        switch (*t->unit_id)
        {
        case 0:
            t->value = (t->value + 7) % M;
            break;
        case 1:
            t->value = (t->value * 2) % M;
            break;
        case 2:
            t->value = (t->value ^ 5) % M;
            break;
        case 3:
            t->value = t->value - 19;
            break;
        case 4:
            printf("value task %d : %d", t->id, t->value);
            break;
        }
        t->unit_count--;
        if(t->unit_count > 0){
            t->unit_id++;
            enqueue(&main_queue, *t);
        }
        else{
            done_tasks++;
        }
    }
    pthread_exit(NULL);
}



int main(){
    pthread_t receptor_t, dispatcher_t, unit_t[5];

    init_queues();

    pthread_create(&receptor_t, NULL, receptor, (void *)NULL);
    pthread_create(&dispatcher_t, NULL, dispatcher, (void *)NULL);

    for(int i=0; i<5; i++){
        pthread_create(&unit_t[i], NULL, unit, (void *)(unit_queues+i));
    }
    pthread_join(receptor_t, NULL);
    pthread_join(dispatcher_t, NULL);
    for(int i=0; i<5; i++){
        pthread_join(unit_t[i], NULL);
    }
    return 0;
}
